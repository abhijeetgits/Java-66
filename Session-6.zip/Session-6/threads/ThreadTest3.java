package co.edureka.threads;
class Natural extends Thread{
 public void run() {
	for(int i=1;i<=8;i++) {
		System.out.println(Thread.currentThread().getName()+" - "+i);
	}
 }
}

class Even extends Thread{
 public void run() {
   for(int i=1;i<=8;i++) {
	  System.out.println(Thread.currentThread().getName()+" - "+(i*2));
   }
 }
}

public class ThreadTest3 {
	public static void main(String[] args) {
		/*create threads*/
		Natural nat = new Natural();
		Even eve = new Even();
		
		/*set names for Threads*/
		nat.setName("Natural");
		eve.setName("Even   ");
		
		/*make thread runnable*/
		nat.start();
		eve.start();
	}
}
