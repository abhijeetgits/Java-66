package co.edureka.threads;

public class WrapperTest2 {

	public static void main(String[] args) {
		int n1 = 25;
		Integer n2 = n1; //boxing
		int n3 = n2; //unboxing
		System.out.println(n1+" | "+n2+" | "+n3);
		System.out.println(n2.getClass().getName());
		
		Integer i1 = Integer.valueOf(10);
		Integer i2 = Integer.valueOf(15);
		Integer i3 = i1 + i2; //unboxing , additon, boxing
		System.out.println(i1+" + "+i2+" = "+i3);
	}
}
