public class Test{
}
class Edureka{
}