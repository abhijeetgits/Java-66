package co.edureka.pack3;
import co.edureka.pack1.*;
import co.edureka.pack2.*;
public class PackTest {
	public static void main(String[] args) {
		//Nums obj = new Nums();
		co.edureka.pack1.Nums obj = new co.edureka.pack1.Nums();
		System.out.println("Sum = "+ obj.add(20, 12));
	}
}