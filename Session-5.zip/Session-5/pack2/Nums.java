package co.edureka.pack2;

public class Nums {
	public int mul(int x, int y) {
		return x*y;
	}	
}
