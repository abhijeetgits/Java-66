package co.edureka.except;

public class Except1 
{
 public static void main(String[] args) {
  int a=10, b=0, c= 0;
  c=a/b;
  System.out.println("result = "+ c);
  System.out.println("** done **");
 }
}
