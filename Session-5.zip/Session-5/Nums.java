interface Nums
{
 int a=10,b=20; //public static final
 void addNum(int x, int y);
 float subNum(float a, float b);
}