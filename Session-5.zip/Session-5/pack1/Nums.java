package co.edureka.pack1;

public class Nums {
	public int add(int x, int y) {
		return x+y;
	}
	public float sub(float a, float b) {
		return a-b;
	}

}
