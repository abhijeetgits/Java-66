package co.edureka.except;

public class ThrowTest {

	public static void main(String[] args) {
	 try {
		 //ArithmeticException aex = new ArithmeticException();
		 ArithmeticException aex = new ArithmeticException("my exception message");
		 //throw aex;
		 throw new ArithmeticException("my exception message");
	 }
	 catch(Exception ex) {
		 System.out.println(ex.getMessage());
		 System.out.println(ex);
	 }

	}

}
